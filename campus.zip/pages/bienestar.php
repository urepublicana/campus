<!DOCTYPE html>
<html lang="en">
  <head>
	<?php require_once("../requiere/head.php"); ?>
  </head>

  <body>
	<?php 
	$pagina = "bienestar";
	require_once("../requiere/menu.php"); ?> 

	<div class="row centered cabecera">
		<div class="col-lg-12">
			<img src="../imgs/bienestar.png" width="300">	
		</div>
	</div>

	<div class="container w">
		<div class="row">
		
			<div class="col-lg-3">
				<img src="../imgs/uni3.png" width="100%">
			</div><!-- col-lg-4 -->
			
			<div class="col-lg-8">
				<h4>BIENESTAR</h4>
				<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even believable. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even believable</p>
			</div><!-- col-lg-4 -->
		</div><!-- row -->
		<br>
		<br>
	</div><!-- container -->
	
	
	<!-- FOOTER -->
	<?php require_once("../requiere/footer.php"); ?> 
  </body>
    <script src="../assets/js/chat-pg.js"></script>
</html>
