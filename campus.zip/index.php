<html lang="es">
	<head>
		<meta http-equiv="refresh" content="0.1; url=pages/index.php" />
		<title>Campus Virtual</title>
	</head>
<body>
</body>
</html>